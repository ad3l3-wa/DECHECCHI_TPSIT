public class Auto extends Veicolo{
    protected int porte;

    public Auto(String s, int a, int b) {
        super(s, a);
        this.porte = b;
    }

    @Override
    public String Descrizione() {
        return "Questo veicolo è un'auto con targa %s anno di immatricolazione %d e %d porte".formatted(targa, anno, porte);
    }
}
