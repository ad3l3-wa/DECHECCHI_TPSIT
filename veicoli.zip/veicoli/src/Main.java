void main() {
    Veicolo a = new Veicolo("AA238BB",2001);
    Auto b = new Auto("AA238CJ",2003, 5);
    Moto c = new Moto("FY542IU",2018, 190);

    Veicolo[] array = {a, b, c};

    for (Veicolo v : array) {
        IO.println(v.Descrizione());
    }
}
