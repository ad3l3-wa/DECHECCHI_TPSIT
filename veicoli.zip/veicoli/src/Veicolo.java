public class Veicolo {
    protected String targa;
    protected int anno;

    public Veicolo(String s, int a) {
        this.targa = s;
        this.anno = a;
    }

    public String Descrizione() {
        return "Veicolo generale con targa %s e anno di immatricolazione %d".formatted(targa, anno);
    }
}
