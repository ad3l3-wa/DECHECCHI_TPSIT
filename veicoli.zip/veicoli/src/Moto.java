public class Moto extends Veicolo {
    protected int cilindrata;

    public Moto(String s, int a, int b) {
        super(s, a);
        this.cilindrata = b;
    }

    @Override
    public String Descrizione() {
        return "Questo veicolo è una moto con targa %s anno di immatricolazione %d e %dcc".formatted(targa, anno, cilindrata);
    }
}
